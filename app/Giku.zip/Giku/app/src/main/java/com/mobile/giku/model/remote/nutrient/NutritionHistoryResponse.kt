package com.mobile.giku.model.remote.nutrient

import com.google.gson.annotations.SerializedName

data class NutritionHistoryResponse(
    @SerializedName("code")
    val code: Int,

    @SerializedName("data")
    val data: NutritionHistoryData? = null
)

data class NutritionHistoryData(
    @SerializedName("id")
    val id: String,

    @SerializedName("confidenceScore")
    val confidenceScore: String,

    @SerializedName("namaMakanan")
    val namaMakanan: String,

    @SerializedName("kandunganGizi")
    val kandunganGizi: KandunganGizi,

    @SerializedName("imageurl")
    val imageUrl: String,

    @SerializedName("createdAt")
    val createdAt: String
)