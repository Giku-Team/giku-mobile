package com.mobile.giku.model.remote.generic

data class GenericResponse(
    val code: Int,
    val message: String
)
