package com.mobile.giku.model.remote.auth

data class RegisterResponse(
    val code: Int,
    val message: String
)
