package com.mobile.giku.viewmodel.analysis

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mobile.giku.model.remote.nutrient.NutritionPredictionResponse
import com.mobile.giku.repository.NutrientRepository
import com.mobile.giku.viewmodel.state.UIState
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

class AnalysisViewModel(private val repository: NutrientRepository) : ViewModel() {

    private val _analysisState = MutableLiveData<UIState>()
    val analysisState: LiveData<UIState> = _analysisState

    private val _nutritionResponse = MutableLiveData<NutritionPredictionResponse>()
    val nutritionResponse: LiveData<NutritionPredictionResponse> = _nutritionResponse

    val selectedImageUri = MutableLiveData<Uri>()

    fun analyze(image: File) {
        when {
            !isValidImageFile(image) -> {
                _analysisState.value = UIState.Error("Only JPG, JPEG, or PNG files are allowed.")
                return
            }
            image.length() > MAX_FILE_SIZE_BYTES -> {
                _analysisState.value = UIState.Error("Image size is too large. Maximum 10 MB.")
                return
            }
            else -> processImageAnalysis(image)
        }
    }

    private fun processImageAnalysis(image: File) {
        _analysisState.value = UIState.Loading
        viewModelScope.launch {
            try {
                val imagePart = prepareImagePart(image)
                val response = repository.PredictNutrition(imagePart)

                when {
                    response.code == 200 -> {
                        _nutritionResponse.postValue(response)
                        _analysisState.postValue(UIState.Success)
                    }
                    else -> {
                        _analysisState.postValue(UIState.Error(
                            response.message.ifEmpty {
                                "Failed to analyze the image. Please try again."
                            }
                        ))
                    }
                }
            } catch (e: Exception) {
                handleAnalysisError(e)
            }
        }
    }

    private fun prepareImagePart(image: File): MultipartBody.Part {
        val requestBody = image.asRequestBody("image/*".toMediaTypeOrNull())
        return MultipartBody.Part.createFormData("image", image.name, requestBody)
    }

    private fun handleAnalysisError(e: Exception) {
        val errorMessage = when (e) {
            is java.io.IOException -> "Connection problems. Check your internet."
            is retrofit2.HttpException -> "The server is having problems. Try again later."
            else -> "An unexpected error occurred. Please try again."
        }
        _analysisState.postValue(UIState.Error(errorMessage))
    }

    private fun isValidImageFile(file: File): Boolean {
        val allowedExtensions = listOf(".jpg", ".jpeg", ".png")
        return file.exists() && allowedExtensions.any {
            file.name.lowercase().endsWith(it)
        }
    }

    companion object {
        private const val MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024
    }
}
