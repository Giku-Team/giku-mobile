package com.mobile.giku.model.remote.stunting

interface StuntingApiService {
}