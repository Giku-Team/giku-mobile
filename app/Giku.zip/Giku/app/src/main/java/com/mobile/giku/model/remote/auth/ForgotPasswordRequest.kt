package com.mobile.giku.model.remote.auth

data class ForgotPasswordRequest(
    val email: String
)
