package com.mobile.giku.model.remote.nutrient

import com.mobile.giku.BuildConfig
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path

interface NutrientHistoryApiService {
    @GET(BuildConfig.GET_NUTRITION_PREDICTION_URL)
    suspend fun getNutritionPrediction(
        @Header("Authorization") token: String,
        @Path("userId") userId: String
    ): Response<NutritionHistoryResponse>
}