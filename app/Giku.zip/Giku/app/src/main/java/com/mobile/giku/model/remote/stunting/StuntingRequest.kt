package com.mobile.giku.model.remote.stunting

data class StuntingRequest(
    val age: Double,
    val gender: Int,
    val height: Double,
)