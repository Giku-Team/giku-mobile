package com.mobile.giku.view.adapter.child

import com.mobile.giku.model.remote.child.ChildData

interface ChildClickListener {
    fun onChildClick(childData: ChildData)
}