package com.mobile.giku.view.ui.analysis

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.mobile.giku.R
import com.mobile.giku.databinding.ActivityAnalysisDetailsBinding
import com.mobile.giku.model.remote.nutrient.NutritionPredictionResponse

class AnalysisDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalysisDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalysisDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadReceivedData()
    }

    private fun loadReceivedData() {
        val imageUriString = intent.getStringExtra(EXTRA_IMAGE_URI)
        val title = intent.getStringExtra(EXTRA_TITLE)
        val confidenceScore = intent.getFloatExtra(EXTRA_CONFIDENCE_SCORE, 0f)
        val result = intent.getStringExtra(EXTRA_RESULT)

        // Load image
        imageUriString?.let { uriString ->
            val imageUri = Uri.parse(uriString)
            binding.ivProductDetails.load(imageUri) {
                crossfade(true)
                placeholder(R.drawable.ic_place_holder)
                error(R.drawable.ic_place_holder)
            }
        }

        binding.tvProductName.text = title
        binding.tvConfidenceScore.text = "Confidence: %.2f%%".format(confidenceScore)
        binding.tvNutritionalContent.text = result
    }

    private fun formatNutritionDetails(response: NutritionPredictionResponse): String {
        val nutrition = response.kandunganGizi

        return """
    Food Nutrition: ${response.namaMakanan}

    Nutrition Information:
    * Calories: ${nutrition.kaloriKcal} kcal
    * Protein: ${nutrition.proteinG} g
    * Fat: ${nutrition.lemakG} g
    * Carbohydrates: ${nutrition.karbohidratG} g
    * Sugar: ${nutrition.gulaG} g
    * Sodium: ${nutrition.natriumG} g

    Vitamins:
    * Vitamin A: ${nutrition.vitaminA}%
    * Vitamin C: ${nutrition.vitaminC}%
    * Vitamin D: ${nutrition.vitaminD}%
    * Vitamin E: ${nutrition.vitaminE}%
    * Vitamin K: ${nutrition.vitaminK}%
    * Vitamin B Complex:
        * Thiamine (B1): ${nutrition.vitaminB1Tiamin}%
        * Riboflavin (B2): ${nutrition.vitaminB2Riboflavin}%
        * Niacin (B3): ${nutrition.vitaminB3Niasin}%
        * Pantothenic Acid (B5): ${nutrition.vitaminB5AsamPantotenat}%
        * Pyridoxine (B6): ${nutrition.vitaminB6Piridoksin}%
        * Folate (B9): ${nutrition.vitaminB9AsamFolat}%
        * Cobalamin (B12): ${nutrition.vitaminB12Kobalamin}%
    * Biotin: ${nutrition.biotin}%

    Minerals:
    * Calcium: ${nutrition.kalsium}%
    * Phosphorus: ${nutrition.fosfor}%
    * Magnesium: ${nutrition.magnesium}%
    * Iron: ${nutrition.zatBesi}%
    * Zinc: ${nutrition.zink}%
    * Potassium: ${nutrition.kalium}%
    * Iodine: ${nutrition.iodium}%
    * Selenium: ${nutrition.selenium}%
    * Copper: ${nutrition.tembaga}%

    Others:
    * Choline: ${nutrition.kolin}%

    Amino Acids:
    * Isoleucine: ${nutrition.isoleusinG} g
    * Leucine: ${nutrition.leusinG} g
    * Lysine: ${nutrition.lisinG} g
    * Methionine: ${nutrition.metioninG} g
    * Phenylalanine: ${nutrition.fenilalaninG} g
    * Threonine: ${nutrition.threoninG} g
    * Tryptophan: ${nutrition.triptofanG} g
    * Valine: ${nutrition.valinG} g
    * Taurine: ${nutrition.taurinG} g
    * Chloride: ${nutrition.kloridaG} g
    """.trimIndent()
    }

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_CONFIDENCE_SCORE = "extra_confidence_score"
        const val EXTRA_RESULT = "extra_result"
    }
}
